<div class="header bg-primary pb-6">
    <div class="container-fluid">
        <div class="header-body">
           {{ $slot }} 
        </div>
    </div>
</div>
